jQuery(function($) {

  window.PluginManager = function() {
    var _getExtListCallback,
      _extensionsChangedCallback;

    function getExtensionsList(callback) {
      _getExtListCallback = callback;
      chrome.send('updateExntensionsList');
    }

    return {
      setExtensionsList: function(list) {
        _getExtListCallback && _getExtListCallback(list);
      },
      setExtensionsChanged: function(ext) {
        _extensionsChangedCallback && _extensionsChangedCallback(ext);
      },
      getExtensionsList: getExtensionsList,
      onExtensionsChanged: function(callback) {
        _extensionsChangedCallback = callback;
      },
      enableExtension: function(id) {
        chrome.send('enableExtension', [id]);
      },
      disableExtension: function(id) {
        chrome.send('disableExtension', [id]);
      },
      removeExtension: function(id) {
        chrome.send('removeExtension', [id]);
      },
      showExtension: function(id) {
        chrome.send('showExtension', [id]);
      },
      hideExtension: function(id) {
        chrome.send('hideExtension', [id]);
      },
      setLoginStatus: function(isLogined) {
        _loginStatusCallback && _loginStatusCallback(isLogined && isLogined[0]);
      },
      getLoginStatus: function(callback) {
        _loginStatusCallback = callback;
        chrome.send('getLoginStatus');
      },
      setSyncStatus: function(val) {
        chrome.send('setSyncStatus', [val]);
      }
    };
  }();

  function render() {
    // TODO 同步checkbox
    // PluginManager.getLoginStatus(function(status) {
    //   if (status.islogined) {
    //     $('.cb-auto-sync input').attr('checked', status.issync)
    //     $('.cb-auto-sync').show();
    //   } else {
    //     $('.cb-auto-sync').hide();
    //   }
    // });

    // render
    PluginManager.getExtensionsList(function(list) {
      var tplFn = doT.template($('#tpl-list').html());
      $('ul.ext-list').html(tplFn(list && list[0]));
    });
  }

  function init() {
    render();
    PluginManager.onExtensionsChanged(render);

    // bind events
    $(document).delegate('.setting .disable', 'click', function() {
      var $li = $(this).parents('li');
      PluginManager.disableExtension($li.attr('id'));
    }).delegate('.setting .enable', 'click', function() {
      var $li = $(this).parents('li');
      PluginManager.enableExtension($li.attr('id'));
    }).delegate('.setting .remove', 'click', function() {
      var $li = $(this).parents('li');
      PluginManager.removeExtension($li.attr('id'));
    }).delegate('.setting .show', 'click', function() {
      var $li = $(this).parents('li');
      PluginManager.showExtension($li.attr('id'));
    }).delegate('.setting .hide', 'click', function() {
      var $li = $(this).parents('li');
      PluginManager.hideExtension($li.attr('id'));
    }).delegate('.cb-auto-sync input', 'change', function() {
      PluginManager.setSyncStatus(this.checked ? 1 : 0);
    }).delegate('a[href!=""]', 'click', function(e) {
      if (/^(se|chrome):/.test(this.href)) {
        e.preventDefault();

        external.AppCmd(external.GetSID(window), "", "main.openurl", this.href, "", function(code, msg) {});
      }
    });
  }

  init();

});